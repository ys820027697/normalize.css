declare const VueOfficeDocx: {
    install?: (vue: any) => void;
    src: string|ArrayBuffer|Blob;
    requestOptions?: any;
    options?: any
};
export default  VueOfficeDocx;