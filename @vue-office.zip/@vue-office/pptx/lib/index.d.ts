declare const VueOfficePptx: {
    install?: (vue: any) => void;
    src: string|ArrayBuffer|Blob;
    rerender?: () => any;
    requestOptions?: any;
    options?: any
};
export default  VueOfficePptx;